import React from "react";
import "./Header.css";

const PageHeader = () => {
  return <h1 className="blog-header">DJ BLOG</h1>;
};

export default PageHeader;
