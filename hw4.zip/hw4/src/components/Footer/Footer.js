import React, { Component } from "react";
import "./Footer.css";

const Footer = () => {
  return <h1 className="blog-header">Footer</h1>;
};

export default Footer;
